@include('header')

<div class = "container">
	@include('home')

	<br>
	<br>
	<br>
		<br>
	<p> </p>
</div>


@include('footer')

