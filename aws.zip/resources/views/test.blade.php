

<div class="row">
	@foreach($items as $item)
		@include ('w-beer-search-card')
	@endforeach
</div>