@include('header')

<div class = "container">
	
	@include('w-searchbar-main')
	@include('w-results-box')

	<br>
	<br>
	<br>
	<br>
	<p> </p>
</div>


@include('footer')


