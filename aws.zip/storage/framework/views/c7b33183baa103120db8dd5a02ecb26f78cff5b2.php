
<div class="row bg-light my-3 pt-3">
	<div class="col-12">
		<div class="row">
			<form action="search">
				<div class="input-group mb-3">
				
					<div class="col col-md-3">
						<select name="criteria" class="form-select" aria-label="Default select example">
							<option value="taps"selected>Find pubs that serve:</option>
							<option value="pubs">Find pub:</option>
							<option value="beers">Find beer:</option>
						</select>
					</div>
					<div class="col col-md-3">
						<input name="searchQ" type="text" class="form-control" placeholder="Beer" aria-label="Username" aria-describedby="basic-addon1">
					</div>
					<div class="col col-md-1">
						<p class="fs-5 text-center"> in: </p>
					</div>

					<div class="col col-md-3 pe-3">
						<input type="text" name="cityQ" class="form-control" placeholder="City" aria-label="Username" aria-describedby="basic-addon1">
					</div>

					<div class="col col-md-2 text-center">
						<button type="submit" class="btn btn-primary">Search</button>
					</div>
				
				</div>
			</form>
		</div>

	</div>
</div>
<?php /**PATH C:\Users\Admin\Documents\Alacrity\Bootcamp\TappFinder_1.0\resources\views/w-searchbar-main.blade.php ENDPATH**/ ?>