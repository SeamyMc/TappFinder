

<br>
<br>
<br>
<div class="row">
	<div class="col">
		<div class="row">
			<div class="col col-4 offset-4">
				<div class="row">
					<div class="col-8 offset-2">
						<img src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Ftse4.mm.bing.net%2Fth%3Fid%3DOIP.xhCfJGKousJdFna0rP0PkgHaHa%26pid%3DApi&f=1" class="img-fluid" alt="...">
					
					</div>
				</div>
				<div class="row text-center">
					<p class="fs-1">Tapp Finder</p>
				</div>
			</div>
		</div>
		<div class="row">
			<div class="col col-10 offset-1">
				<?php echo $__env->make('w-searchbar-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>		
			</div>
		</div>
	</div>
</div>

<?php /**PATH C:\Users\Admin\Documents\Alacrity\Bootcamp\TappFinder_1.0\resources\views/home.blade.php ENDPATH**/ ?>