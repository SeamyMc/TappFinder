<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class = "container">
	<?php if($category == "pub"): ?>
		<?php echo $__env->make('pub_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php else: ?>
		<?php echo $__env->make('beer_info', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	<?php endif; ?>
	<br>
	<br>
	<br>
	<br>
	<p></p>
</div>


<?php echo $__env->make('footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>


<?php /**PATH C:\Users\Admin\Documents\Alacrity\Bootcamp\TappFinder_1.0\resources\views/info.blade.php ENDPATH**/ ?>