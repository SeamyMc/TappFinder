<div class="col-lg-3 col-md-4 col-sm-6 col-12 p-2">
	<a style="all:unset; cursor:pointer" href="/beer/<?php echo e($item->id); ?>">
		<div class="card" style="width: 100%;">
			<img style="height:200px; object-fit:cover;" src="<?php echo e($item->image); ?>">
<!-- 			<div  class="position-absolute me-2 mt-2 top-0 end-0">
				<a href="#" class="delete-btn btn-sm btn-outline-dark">X</a>
		 	</div> -->
			<div class="card-body">
				<div class="row">
					<div class = col-9>
						<h5 class="card-title"><?php echo e($item->name); ?></h5>
						<p class="card-text">ABV: <?php echo e($item->abv); ?>%</p>
						<p class="card-text">
						Sold in: <?php echo e($item->taps_count); ?> pubs
					</div>
				</div>
			</div>
		</div>
	</a>
</div><?php /**PATH C:\Users\Admin\Documents\Alacrity\Bootcamp\TappFinder_1.0\resources\views/w-beer-search-card.blade.php ENDPATH**/ ?>