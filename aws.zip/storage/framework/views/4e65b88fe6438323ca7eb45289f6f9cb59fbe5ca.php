
<div class="row bg-light my-3 pt-3">
	<div class="results col-12">
		<div class="row">
			<div class="col">
				<p class="fs-4 text">
					<?php if($criteria == "taps"): ?>
						Showing Pubs that serve 
						<?php if($searchQ == ""): ?>
							any Beer
						<?php else: ?>
							"<?php echo e($searchQ); ?>"
						<?php endif; ?>
					<?php else: ?>
						Showing: <?php echo e($criteria); ?>

					<?php endif; ?>
				</p>
			</div>
		</div>
		<div class="row">
			<?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<?php if($criteria == "beers"): ?>
					<?php echo $__env->make('w-beer-search-card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endif; ?>

				<?php if($criteria == "pubs" or $criteria == "taps"): ?>
					<?php echo $__env->make('w-pub-search-card', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
				<?php endif; ?>
			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		</div>
	</div>
</div>
<?php /**PATH C:\Users\Admin\Documents\Alacrity\Bootcamp\TappFinder_1.0\resources\views/w-results-box.blade.php ENDPATH**/ ?>