<html lang="en">
  <head>
	    <meta charset="utf-8">
	    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
		<link href="<?php echo e(asset('css/custom.css')); ?>" rel="stylesheet">
		<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
	    <title>Tapp Finder</title>
  	</head>

 	<body>
 		<div class = "container">

		<?php /**PATH C:\Users\Admin\Documents\Alacrity\Bootcamp\TappFinder_1.0\resources\views/header.blade.php ENDPATH**/ ?>