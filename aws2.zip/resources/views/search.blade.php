@include('header')


	
	@include('w-searchbar-main')
	@include('w-results-box')



@include('footer')


