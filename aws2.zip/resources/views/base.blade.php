@include('header')


	@include('home')


@include('footer')

