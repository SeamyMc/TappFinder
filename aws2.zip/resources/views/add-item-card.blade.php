	<div class="col-lg-3 col-md-4 col-sm-6 col-12 p-2">
		<a style="all:unset; cursor:pointer" href="/add{{$criteria}}">
		<div class="card" style="width: 100%;">
			<img style="height:200px; object-fit:cover; filter:grayscale(0);" src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fwww.freepnglogos.com%2Fuploads%2Fplus-icon%2Fadd-plus-icon-28.png&f=1&nofb=1">
			<div class="card-body">
				<div class="row">
					<div class = col-9>
						<p class="card-text"> add </p>
					</div>
				</div>
			</div>
		</div>
		</a>
	</div>
