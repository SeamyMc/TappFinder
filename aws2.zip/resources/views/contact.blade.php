@include('header')

<h1>
	Contact
</h1>
	
@include('footer')


