	<div class="col-lg-3 col-md-4 col-sm-6 col-12 p-2">
		<a style="all:unset; cursor:pointer" href="/add<?php echo e($criteria); ?>">
		<div class="card" style="width: 100%;">
			<img style="height:200px; object-fit:cover; filter:grayscale(0);" src="https://external-content.duckduckgo.com/iu/?u=https%3A%2F%2Fwww.freepnglogos.com%2Fuploads%2Fplus-icon%2Fadd-plus-icon-28.png&f=1&nofb=1">
			<div class="card-body">

			</div>
		</div>
		</a>
	</div>
<?php /**PATH C:\Users\Admin\Documents\Alacrity\Bootcamp\TappFinder_1.0\resources\views/add-item-card.blade.php ENDPATH**/ ?>