<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Tap;
use App\Models\Beer;
use App\Models\Pub;

class TapSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
  
        Tap::truncate();
        $pubs = Pub::all();
        $beers = Beer::all();


        for ($i=0; $i<10; $i++){
            $pub = $pubs->random();
            $beer = $beers->random();

    		Tap::create([
    		    'beer_id' => $beer->id,
    		    'pub_id' => $pub->id,
    		    'price' => 350,
    	    ]);
        }

        // Tap::create([
        //     'beer_id' => 51,
        //     'pub_id' => 51,
        //     'price' => 410,
        // ]);

        // Tap::create([
        //     'beer_id' => 51,
        //     'pub_id' => 52,
        //     'price' => 390,
        // ]);

        // Tap::create([
        //     'beer_id' => 53,
        //     'pub_id' => 52,
        //     'price' => 390,
        // ]);
    }
}
